"""Adventure Guide: a sixth tab in the status menu that lists bosses and other loot sources with their drops.

The tab (after Badass Rank) is built from the game's own status menu movie at startup, in memory; nothing from the game is
stored in this mod. See README.txt for what the tab does and how to report a problem (adventure_guide.log).

Developer trigger: if a file named dev.flag exists in this folder, a Python file named exec.now.py dropped here runs inside the
game within a second (its say() output lands in adventure_guide.log). Releases ship without dev.flag.
"""
import time
from pathlib import Path

import unrealsdk
from mods_base import build_mod, get_pc, hook

HERE = Path(__file__).parent
LOG = HERE / "adventure_guide.log"
EXEC = HERE / "exec.now.py"
DEV = HERE / "dev.flag"
__version__ = "0.9.0-beta"
_last = 0.0
_t0 = time.monotonic()
_tab_checked = False

try:  # a fresh log per game session (the log is what testers send back)
    LOG.write_text("", encoding="utf-8")
except OSError:
    pass


def say(msg: str) -> None:
    unrealsdk.logging.info(f"[AdventureGuide] {msg}")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")
    except OSError:
        pass


@hook("WillowGame.WillowGameViewportClient:Tick", hook_identifier="adventure_guide_exec")
def tick(*_: object) -> None:
    global _last, _tab_checked
    t = time.monotonic()
    if t - _last < 1.0:
        return
    _last = t
    if not _tab_checked and t - _t0 > 8:  # the status menu movie must be patched before it is first opened
        _tab_checked = True
        try:
            guide.enable_tab()
        except Exception:  # noqa: BLE001
            import traceback

            say("enable_tab error: " + traceback.format_exc()[-400:])
    if not DEV.exists() or not EXEC.exists():
        return
    src = EXEC.read_text(encoding="utf-8")
    EXEC.unlink()
    try:
        exec(compile(src, "exec.py", "exec"), {**globals(), "pc": get_pc(possibly_loading=True)})
    except Exception:  # noqa: BLE001
        import traceback

        say("exec error: " + traceback.format_exc()[-800:])


try:
    from . import guide

    guide.install(say)
except Exception:  # noqa: BLE001
    import traceback

    say("guide install failed: " + traceback.format_exc()[-600:])

build_mod(
    name="Adventure Guide",
    description="A sixth status-menu tab: bosses, special enemies, vendors and world drops with every legendary and unique item they drop. R searches, Q changes the sort.",
    hooks=[tick],
    auto_enable=True,
)
